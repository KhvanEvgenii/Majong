Conditions = { standart: 'standart', win: 'win', lostheart: 'lostheart', end: 'end', pause: 'pause' };

