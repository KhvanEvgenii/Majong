class Storage {
    constructor() {
        this.storage = window.localStorage;
    }

    getItem(key) {
        return this.storage.getItem(key);
    }

    setItem(key, value) {
        this.storage.setItem(key, value);
    }

    removeItem(key) {
        this.storage.removeItem(key);
    }

    saveGame(game) {
        this.setItem("gameLVL", game.gameLVL);
        this.setItem("currentLife", game.currentLife);
        this.setItem("helpCount", game.helpCount);
        this.setItem("sound", game.sound.muted ? 0 : 1);
        this.saveYandex(game);
    }

    clearAll() {
        this.storage.clear();
    }

    loadGame() {
        const yandexData = JSON.parse(window.yandexData);
        console.log('yandexData');
        console.log(yandexData);
        if (yandexData) {
            try {
                const data = {
                    gameLVL: parseInt(yandexData.gameLVL),
                    currentLife: parseInt(yandexData.currentLife),
                    helpCount: parseInt(yandexData.helpCount),
                    sound: parseInt(yandexData.sound)
                }
                return data;
            } catch (error) {
                console.error('Ошибка при загрузке данных из Яндекса:', error);
                return this.storage;
            }
        } else {
            return this.storage;
        }
    }

    getSoundStatus() {
        return this.storage.getItem('sound') ? this.storage.getItem('sound') : 1;
    }

    setSoundStatus(status) {
        this.storage.setItem('sound', status)
    }

    saveYandex(game) {
        console.log(`Данные загружаемые в Яндекс`);
        console.log(window.yandexData);

        console.log({
            gameLVL: parseInt(game.gameLVL),
            currentLife: parseInt(game.currentLife),
            helpCount: parseInt(game.helpCount),
            sound: game.sound.muted ? 0 : 1
        });
        window.player.setStats(
            {
                gameLVL: parseInt(game.gameLVL),
                currentLife: parseInt(game.currentLife),
                helpCount: parseInt(game.helpCount),
                sound: game.sound.muted ? 0 : 1
            }
        );
    }
}