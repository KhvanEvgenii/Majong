
const directions = {
    up:    { dx: -1, dy:  0 },
    down:  { dx:  1, dy:  0 },
    left:  { dx:  0, dy: -1 },
    right: { dx:  0, dy:  1 }
};

// Проверяем, можно ли идти в данном направлении
function canMove(matrix, x, y,goalX, goalY) {

    if (x == goalX && y == goalY){
        return true;
    }

    return x >= 0 && y >= 0 && x < matrix.length && y < matrix[0].length && matrix[x][y] === 0;
}

// Функция поиска нового направления
function findDirection(matrix, x, y, goalX, goalY) {
    // Приоритет: двигаемся в сторону цели
    const dx = Math.sign(goalX - x);
    const dy = Math.sign(goalY - y);

    // Пробуем двигаться в приоритетном направлении
    if (dx !== 0 && canMove(matrix, x + dx, y,goalX,goalY)) {
        return dx > 0 ? "down" : "up";
    }
    if (dy !== 0 && canMove(matrix, x, y + dy,goalX,goalY)) {
        return dy > 0 ? "right" : "left";
    }

    // Если приоритетное движение невозможно, ищем другое направление
    for (let dir in directions) {
        let nx = x + directions[dir].dx;
        let ny = y + directions[dir].dy;
        if (canMove(matrix, nx, ny, goalX, goalY)) return dir;
    }

    return null; // Путь заблокирован
}

// Двигаемся в направлении, пока не упремся
function moveForward(matrix, x, y, direction, goalX, goalY) {
    let path = [];
    let { dx, dy } = directions[direction];

    while (canMove(matrix, x + dx, y + dy, goalX, goalY)) {
        x += dx;
        y += dy;
        path.push([x, y]);
    }

    return { x, y, path };
}

// Основная функция поиска пути
function findPath(matrix, start, end, maxTurns) {
    let [x, y] = start;
    let [goalX, goalY] = end;
    let path = [[x, y]];
    let turns = 0;
    let direction = findDirection(matrix, x, y, goalX, goalY);

    if (!direction) return null; // Нет пути

    while (x !== goalX || y !== goalY) {
        let result = moveForward(matrix, x, y, direction, goalX, goalY);
        x = result.x;
        y = result.y;
        path.push(...result.path);

        if (x === goalX && y === goalY) break; // Достигли цели

        let newDirection = findDirection(matrix, x, y, goalX, goalY);
        if (!newDirection) return null; // Если нет пути

        if (newDirection !== direction) {
            turns++;
            if (turns > maxTurns) return null; // Превышено число поворотов
        }
        direction = newDirection;
    }

    return { path, turns };
}


function isPath(matrix, startRow, startCol, endRow, endCol) {

    if (startCol == endCol && startCol == numCols -1) {
        return true;
    }

    if (startRow == endRow && startRow == numRows -1) {
        return true;
    }

    // Defining visited array to keep
    // track of already visited indexes
    let visited = new Array(numCols);
    for (let i = 0; i < numRows; i++) {
        visited[i] = new Array(numRows);
        for (let j = 0; j < numRows; j++) {
            visited[i][j] = false;
        }
    }

    // Flag to indicate whether the
    // path exists or not
    let flag = false;

    if (checkPath(
        matrix, startRow, startCol, visited, endRow, endCol)) {
        // if path exists
        flag = true;
    }

    return flag;
}

function isSafe(i, j, matrix) {
    if (
        i >= 0 && i < matrix.length
        && j >= 0
        && j < matrix[0].length)
        return true;
    return false;
}

function checkPath(matrix, i, j, visited, endRow, endCol) {
    // Checking the boundaries, walls and
    // whether the cell is unvisited
    if (
        isSafe(i, j, matrix)
        && !visited[i][j]) {
        // Make the cell visited
        visited[i][j] = true;

        // if the cell is the required
        // destination then return true
        if (i == endRow && j == endCol)
            return true;

        if (matrix[i][j] != 0)
            return false;

        // traverse up
        let up = checkPath(
            matrix, i - 1,
            j, visited, endRow, endCol, enableVal);

        // if path is found in up
        // direction return true
        if (up)
            return true;

        // traverse left
        let left
            = checkPath(
                matrix, i, j - 1, visited, endRow, endCol, enableVal);

        // if path is found in left
        // direction return true
        if (left)
            return true;

        // traverse down
        let down = checkPath(
            matrix, i + 1, j, visited, endRow, endCol, enableVal);

        // if path is found in down
        // direction return true
        if (down)
            return true;

        // traverse right
        let right
            = checkPath(
                matrix, i, j + 1,
                visited, endRow, endCol, enableVal);

        // if path is found in right
        // direction return true
        if (right)
            return true;
    }
    // no path has been found
    return false;
}