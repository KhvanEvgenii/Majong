const gameContainer = document.getElementById('gameContainer');
const gameBoard = document.getElementById('game-board');
const levelElement = document.getElementById('level-number');
const progressBar = document.getElementById("myBar");
const hearts = document.getElementsByClassName("heartGame");
const heartsModal = document.getElementsByClassName("heartModal");
const pauseBut = document.getElementById('but_pause');

const blurDiv = document.getElementById("blur");
const startMenu = document.getElementById("startMenu");

const modalHead = document.getElementById('modalHead');
const butModal = document.getElementById('but_modal');
const but_start = document.getElementById('but_start');
const timeUpModal = document.getElementById('timeUpModal');

butModal.addEventListener('click', () => reStartGame())
but_start.addEventListener('click', () => reStartGame())
pauseBut.addEventListener('click', () => pauseGame())

// Добавляем функцию закрытия модального окна
function closeTimeUpModal() {
    document.getElementById('timeUpModal').style.display = 'none';
}

// game settings
const numCols = 14;
const numRows = 10;
const gameSize = numCols * numRows / 2;
const startdiff = 7;
const T1 = 12000;  // Время на первый уровень (сек)
const dT = 5;    // Уменьшение времени на уровень (сек)
const B_max = 5; // Максимальное бонусное время (сек)
const t_b = 400;   // Пороговое время для бонуса (сек)
const levels = 15; // Количество уровней
const Conditions = { standart: 'standart', win: 'win', lostheart: 'lostheart', end: 'end', pause: 'pause' };


// game var
let finalTime; // Время таймера (сек)
let pairTime; // время для клика
let levelTime; // Максимальное время на этот раунд (сек)
let currentLife = 3; // Количесто жизней
let gametimer;
let gameCondition = Conditions.standart;;

let gameLVL = 1;
levelElement.innerText = gameLVL;

const tileValues = ['30', '31', '32', '33', '34', '36', '37', '38', '39', '51'];
let selectedTiles = [];
let matrix = [];

function createQueue() {
    // Коты
    // Собаки
    // Хомяки 30-39
    // Максимум 34
    const allTiles = [
        '30', '31', '32', '33', '34', '36', '37',
        '38', '39', '41', '42', '43', '51', '52',
        '53', '54', '55', '56', '57', '58', '59',
        '60', '61', '62', '63', '64', '65', '66',
        '67', '68', '70', '71', '72', '74'
    ];

    tileValues.length = 0;

    let currentdiff = startdiff + gameLVL;

    while (tileValues.length !== gameSize) {
        for (let i = 0; i < currentdiff; i++) {
            if (tileValues.length == gameSize)
                break;
            tileValues.push(allTiles[i]);
        }
    }
}

function start_countdown() {

    gametimer = setInterval(function () {
        finalTime--;
        pairTime++;

        progressBar.style.width = (finalTime / levelTime * 100) + '%';

        if (finalTime <= 0) {
            currentLife--;
            // Заменяем alert на показ модального окна
            if (currentLife == 0) {
                gameCondition = Conditions.end;
                updateHeart();
                showModalDialoge();
            }
            else {
                gameCondition = Conditions.lostheart;
                updateHeart();
                showModalDialoge();
            }

            clearInterval(gametimer);
        }

    }, 10);
}

// Функция расчета бонусного времени
function calculateBonusTime(pairTime) {
    return pairTime <= t_b ? B_max * (1 - pairTime / t_b) * 100 : 0;
}

function createTiles() {
    matrix = [];
    const values = [...tileValues, ...tileValues].sort(() => Math.random() - 0.5);

    for (let i = 0; i < numRows; i++) {
        let row = [];
        for (let j = 0; j < numCols; j++) {
            row.push(values[i * numCols + j]);
        }
        matrix.push(row);
    }
}

function createTable() {
    const table = document.createElement('table');
    table.id = 'matrix-table';

    for (let i = 0; i < matrix.length; i++) {
        const row = document.createElement('tr');
        for (let j = 0; j < matrix[i].length; j++) {

            const number = matrix[i][j];
            const tile = document.createElement('td');
            // tile.textContent = matrix[i][j];
            tile.classList.add('tile');
            tile.classList.add(`row${i}`);
            tile.classList.add(`col${j}`);
            tile.classList.add(`val${matrix[i][j]}`);
            tile.addEventListener('click', () => selectTile(tile));

            const image = document.createElement('img');
            // image.width = 70;
            // image.height = 70;
            image.alt = "Плитка";
            image.src = `plates/white/${number}.svg`;
            tile.append(image);

            row.appendChild(tile);
        }
        table.appendChild(row);
    }

    // Добавляем таблицу после игрового поля
    gameBoard.appendChild(table);
}

function selectTile(tile) {
    if (tile.classList.contains('selected') || tile.classList.contains('matched')) return;

    tile.classList.add('selected');
    selectedTiles.push(tile);

    if (selectedTiles.length === 2) {
        checkMatch();
    }
}

function checkMatch() {
    const [tile1, tile2] = selectedTiles;

    let tile1row;
    let tile1col;
    let tile2row;
    let tile2col;
    let tile1value;
    let tile2value;

    for (let i = 0; i < tile1.classList.length; i++) {
        const className = tile1.classList[i];

        if (className.includes('col'))
            tile1col = parseInt(className.replaceAll('col', ''), 10);
        if (className.includes('row'))
            tile1row = parseInt(className.replaceAll('row', ''), 10);
        if (className.includes('val'))
            tile1value = className.replaceAll('val', '');
    }

    for (let i = 0; i < tile2.classList.length; i++) {
        const className = tile2.classList[i];

        if (className.includes('col'))
            tile2col = parseInt(className.replaceAll('col', ''), 10);
        if (className.includes('row'))
            tile2row = parseInt(className.replaceAll('row', ''), 10);
        if (className.includes('val'))
            tile2value = className.replaceAll('val', '');

    }

    if (tile1value === tile2value) {

        let path = findPath(matrix, [tile1row,tile1col], [tile2row, tile2col], 3);
        console.log(path);
        if (path) {
            tile1.classList.add('matched');
            tile2.classList.add('matched');
            matrix[tile1row][tile1col] = 0;
            matrix[tile2row][tile2col] = 0;

            let bonusTime = calculateBonusTime(pairTime);
            finalTime = Math.min(levelTime, finalTime + bonusTime);
            pairTime = 0;
        }
        else {
            paintBackGround(tile1, tile2);
        }
    } else {
        paintBackGround(tile1, tile2);
    }

    selectedTiles = [];
    checkgamecondition();
}

function checkgamecondition() {
    let winCondition = true;

    for (let i = 0; i < matrix.length; i++) {
        for (let j = 0; j < matrix[i].length; j++) {
            if (matrix[i][j]) {
                winCondition = false;
            }
        }
    }

    if (winCondition) {
        gameCondition = Conditions.win;
        showModalDialoge();
        clearInterval(gametimer);
    }
}

function pauseGame(){
    clearInterval(gametimer);
    gameCondition = Conditions.pause;
    showModalDialoge();
}

function reStartGame() {
    
    if (gameCondition != Conditions.pause)
    {
        levelTime = T1 - (gameLVL - 1) * 100 * dT;
        finalTime = levelTime;
        pairTime = 0;
    }

    if (gameCondition == Conditions.win) {
        gameLVL++;
    }
    if (gameCondition == Conditions.end) {
        currentLife = 3;
        gameLVL = 1;
    }
    if (gameCondition != Conditions.lostheart && gameCondition != Conditions.pause) {
        clearTable();
        createQueue();
        createTiles();
        createTable();
    }

    updateInterface();

    gameCondition = Conditions.standart;

    start_countdown();
}

// Инициализация игры
// reStartGame();