
const directions = {
    up: { dx: -1, dy: 0 },
    down: { dx: 1, dy: 0 },
    left: { dx: 0, dy: -1 },
    right: { dx: 0, dy: 1 }
};

let allPath;



function isPath(matrix, startRow, startCol, endRow, endCol) {

    if (startCol == endCol && startCol == numCols - 1) {
        return true;
    }

    if (startRow == endRow && startRow == numRows - 1) {
        return true;
    }

    // Defining visited array to keep
    // track of already visited indexes
    let visited = new Array(numRows);
    for (let i = 0; i < numRows; i++) {
        visited[i] = new Array(numCols);
        for (let j = 0; j < numCols; j++) {
            visited[i][j] = false;
        }
    }

    // Flag to indicate whether the
    // path exists or not
    let flag = false;
    let path = [];
    allPath = [];
    let newPath = checkPath(matrix, startRow, startCol, visited, endRow, endCol, path);
    if (allPath.length > 0) {

        if (allPath.length > 1)
        {
            let test = true;
        }
        // if path exists
        flag = true;
    }

    console.log(allPath);

    return flag;
}

function isSafe(i, j, matrix) {
    if (
        i >= 0 && i < matrix.length
        && j >= 0
        && j < matrix[0].length)
        return true;
    return false;
}

function checkPath(matrix, i, j, visited, endRow, endCol, path) {
    // Checking the boundaries, walls and
    // whether the cell is unvisited
    if (isSafe(i, j, matrix) && !visited[i][j]) {
        // Make the cell visited
        visited[i][j] = true;
        path.push({ i, j });
        // if the cell is the required
        // destination then return true
        if (i == endRow && j == endCol){
            allPath.push(path);
            return true;
        }

        if (matrix[i][j] != 0) {
            if (!(path[0].i == i && path[0].j == j)) {
                return false;
            }
        }

        for (let dir in directions) {
            let ni = i + directions[dir].dx;
            let nj = j + directions[dir].dy;

            let newPath = [];
            for (let index = 0; index < path.length; index++)
                {
                    newPath.push(path[index]);
                }

            let newVisited = [...visited];

            checkPath(matrix, ni, nj, newVisited, endRow, endCol, newPath);
        }




        // // traverse up
        // let up = checkPath(
        //     matrix, i - 1,
        //     j, visited, endRow, endCol, path);

        // // if path is found in up
        // // direction return true
        // if (up) {
        //     path.unshift({i:i - 1, j});
        //     return true;
        // }

        // // traverse left
        // let left = checkPath(
        //     matrix, i, j - 1, visited, endRow, endCol, path);

        // // if path is found in left
        // // direction return true
        // if (left) {
        //     path.unshift({i, j:j-1});
        //     return true;
        // }
        // // traverse down
        // let down = checkPath(
        //     matrix, i + 1, j, visited, endRow, endCol, path);

        // // if path is found in down
        // // direction return true
        // if (down) {
        //     path.unshift({i:i+1, j});
        //     return true;
        // }

        // // traverse right
        // let right = checkPath(
        //     matrix, i, j + 1, visited, endRow, endCol, path);

        // // if path is found in right
        // // direction return true
        // if (right) {
        //     path.unshift({i, j:j+1});
        //     return true;
        // }
    }
    // no path has been found
    return false;
}