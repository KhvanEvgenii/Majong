function updateHeart() {
    for (let i = 0; i < 3; i++) {
        const gameHeartsClasses = hearts[i].classList;
        const modalHeartsClasses = heartsModal[i].classList;

        if (i <= currentLife - 1) {
            gameHeartsClasses.add("heartsFull");
            gameHeartsClasses.remove("heartsBroken");
            modalHeartsClasses.add("heartsFull");
            modalHeartsClasses.remove("heartsBroken");
        }

        if (i > currentLife - 1) {
            gameHeartsClasses.remove("heartsFull");
            gameHeartsClasses.add("heartsBroken");
            modalHeartsClasses.remove("heartsFull");
            modalHeartsClasses.add("heartsBroken");
        }
    }
}

function showModalDialoge() {

    blurDiv.style.display = 'block';

    switch (gameCondition) {
        case Conditions.win:
            modalHead.innerHTML = '<h1>Поздравляем!</h1><h2>Уровень пройден</h2>';
            butModal.textContent = 'Следующий уровень';
            break;
        case Conditions.lostheart:
            modalHead.innerHTML = '<h1>Упс...</h1><h2> Минус жизнь</h2> ';
            butModal.textContent = 'Продолжить играть';
            break;
        case Conditions.end:
            modalHead.innerHTML = '<h1>Сердец больше нет</h1><h2> Попробуйте еще раз</h2> ';
            butModal.textContent = 'Начать с начала';
            break;
        case Conditions.pause:
            modalHead.innerHTML = '<h1>Пауза</h1><h2></h2> ';
            butModal.textContent = 'Продолжить';
            break;
    }

    timeUpModal.style.display = 'block';
}

function hideModalDialoge() {
    gameContainer.style.display = 'block';
    startMenu.style.display = 'none';
    timeUpModal.style.display = 'none';
    blurDiv.style.display = 'none';
}

function paintBackGround(tile1, tile2) {
    setTimeout(() => {
        tile1.classList.remove('selected');
        tile2.classList.remove('selected');
    }, 300);
    tile1.classList.add('unpair');
    tile2.classList.add('unpair');
    setTimeout(() => {
        tile1.classList.remove('unpair');
        tile2.classList.remove('unpair');
    }, 700);
}

function updateInterface() {
    hideModalDialoge();
    levelElement.innerText = gameLVL;
    updateHeart();
}

function clearTable() {
    while (gameBoard.firstChild) {
        gameBoard.removeChild(gameBoard.firstChild);
    }
}