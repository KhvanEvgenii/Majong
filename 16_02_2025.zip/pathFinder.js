
function isPath(matrix, startRow, startCol, endRow, endCol) {

    // Defining visited array to keep
    // track of already visited indexes
    let visited = new Array(numCols);
    for (let i = 0; i < numRows; i++) {
        visited[i] = new Array(numRows);
        for (let j = 0; j < numRows; j++) {
            visited[i][j] = false;
        }
    }

    // Flag to indicate whether the
    // path exists or not
    let flag = false;

    if (checkPath(
        matrix, startRow, startCol, visited, endRow, endCol,matrix[startRow][startCol])) {
        // if path exists
        flag = true;
    }
    // for (let i = 0; i < numRows; i++) {
    //     for (let j = 0; j < numCols; j++) {
    //         // if matrix[i][j] is source
    //         // and it is not visited

    //         if (
    //             i == startRow
    //             && j == startCol
    //             && !visited[i][j])

    //             // Starting from i, j and
    //             // then finding the path
    //             if (checkPath(
    //                 matrix, i, j, visited, endRow, endCol)) {
    //                 // if path exists
    //                 flag = true;
    //                 break;
    //             }
    //     }
    // }
    return flag;
    // if (flag)
    //     document.write("YES<br>");
    // else
    //     document.write("NO<br>");
}

function isSafe(i, j, matrix) {
    if (
        i >= 0 && i < matrix.length
        && j >= 0
        && j < matrix[0].length)
        return true;
    return false;
}

function checkPath(matrix, i, j, visited, endRow, endCol, enableVal) {
    // Checking the boundaries, walls and
    // whether the cell is unvisited
    if (
        isSafe(i, j, matrix)
        && !visited[i][j]) {
        // Make the cell visited
        visited[i][j] = true;

        // if the cell is the required
        // destination then return true
        if (i == endRow && j == endCol)
            return true;

        if (matrix[i][j] != enableVal && matrix[i][j] != 0)
            return false;

        // traverse up
        let up = checkPath(
            matrix, i - 1,
            j, visited, endRow, endCol, enableVal);

        // if path is found in up
        // direction return true
        if (up)
            return true;

        // traverse left
        let left
            = checkPath(
                matrix, i, j - 1, visited, endRow, endCol, enableVal);

        // if path is found in left
        // direction return true
        if (left)
            return true;

        // traverse down
        let down = checkPath(
            matrix, i + 1, j, visited, endRow, endCol, enableVal);

        // if path is found in down
        // direction return true
        if (down)
            return true;

        // traverse right
        let right
            = checkPath(
                matrix, i, j + 1,
                visited, endRow, endCol, enableVal);

        // if path is found in right
        // direction return true
        if (right)
            return true;
    }
    // no path has been found
    return false;
}