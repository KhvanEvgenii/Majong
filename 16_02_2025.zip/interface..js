const hearts = document.getElementsByClassName("heart");

function updateHeart(currentLife) {
    const allclases = hearts[currentLife - 1].classList;
    allclases.remove("heartsFull");
    allclases.add("heartsBroken");
}